import re
import urllib
from flask import Flask

app = Flask(__name__)

@app.route('/',methods = ['GET','POST'])
def get_latest_stories():
    """Function for getting latest stories from time.com

    Returns:
        latest_stories: dict
    """
    URL = "https://time.com"

    latest_stories = list()

    # getting the latest stories from time.com
    latest_stories_pattern = re.compile('<li class="latest-stories__item">(.+?)</li>')
    htmlfile = urllib.request.urlopen(URL)
    htmltext = str(htmlfile.read())
    stories = re.findall(latest_stories_pattern, htmltext)

    # getting the story titles and links from each of the stories
    for story in stories:
        # getting the story titles from each of the stories
        story_title_pattern = re.compile(
            '<h3 class="latest-stories__item-headline">(.+?)</h3>'
        )
        story_title = re.findall(story_title_pattern, story)[0]
        story_title = story_title.replace("\\'", "'")

        # getting the story link from each of the stories
        story_link_pattern = re.compile('<a href="(.+?)">')
        story_link = re.findall(story_link_pattern, story)[0]
        story_link = URL + story_link

        story = {"title": story_title, "link": story_link}

        latest_stories.append(story)
    return latest_stories

if __name__ == '__main__':
    app.run()
